<!DOCTYPE html>
<html lang="en">
<head>
<title>CIS Scheduling Program</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  * {
  box-sizing: border-box;
}

body {
   background-color: #white;
  font-family: Verdana, Verdana, sans-serif;
  font-size: 13px
}

/* Style the header */
header {
  background-color: #4C80AF;
  padding: 30px;
  text-align: left;
  font-size: 15px;
  color: white;
}
<br>
nav {
  float: left;
  width: 30%;
  height: 500px; /* only for demonstration, should be removed */
  background: #F1EDED;
  padding: 20px;
}
</style>
</head>
<body>
<header>
  <h2>CIS Scheduling Program</h2>
</header>
</body>
</html>
